#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_LEN 10000
void read_input(char *arr);