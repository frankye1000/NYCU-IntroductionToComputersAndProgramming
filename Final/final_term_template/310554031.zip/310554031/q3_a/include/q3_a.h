#include <stdio.h>
#include <math.h>
#include <string.h>


void deal_with_ROC(char*);
int week(int, int,int);
void sample(char*);
void ROC_sample(char*);
int read_input(char*);
void print_month(int);
void print_week(int);